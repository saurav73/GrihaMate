"use client"

import * as React from "react"
import { Mic, Search, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"

export function AISearchDialog() {
  const [isListening, setIsListening] = React.useState(false)
  const [query, setQuery] = React.useState("")

  const toggleListening = () => {
    setIsListening(!isListening)
    if (!isListening) {
      setQuery("Finding verified 2BHK rooms in Kathmandu near Shanti Nagar...")
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="bg-[#2D3142] hover:bg-[#1F222E] rounded-xl h-12 px-8 flex items-center gap-2">
          AI Search <Sparkles className="size-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] bg-[#F2EDE4] border-[#DED9D0]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="size-5 text-[#2D3142]" />
            AI Voice Search
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center py-12">
          <button
            onClick={toggleListening}
            className={`size-24 rounded-full flex items-center justify-center transition-all duration-500 ${
              isListening
                ? "bg-red-500 shadow-[0_0_40px_rgba(239,68,68,0.4)] scale-110"
                : "bg-[#2D3142] hover:bg-[#1F222E] shadow-xl"
            }`}
          >
            <Mic className={`size-10 text-white ${isListening ? "animate-pulse" : ""}`} />
          </button>
          <p className="mt-8 text-lg font-medium text-center px-4">
            {isListening ? "Listening to your request..." : "Tap the mic and say what you're looking for"}
          </p>
          <p className="mt-2 text-sm text-muted-foreground text-center italic">
            "Find me a 2BHK room with good sunlight in Lalitpur under 25k"
          </p>

          {query && (
            <div className="mt-8 w-full bg-white p-4 rounded-xl border border-[#DED9D0] animate-in fade-in slide-in-from-bottom-2">
              <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Transcribed</div>
              <div className="text-base">{query}</div>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Input placeholder="Or type your request here..." className="flex-1 bg-white border-[#DED9D0]" />
          <Button variant="outline" className="border-[#DED9D0] bg-white">
            <Search className="size-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
