import { Building2, Search, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#F2EDE4] flex flex-col items-center justify-center p-6 text-center">
      <div className="size-20 rounded-3xl bg-white border border-[#DED9D0] flex items-center justify-center mb-8 shadow-xl">
        <Building2 className="size-10 text-[#2D3142]" />
      </div>
      <h1 className="text-6xl md:text-8xl font-black text-[#2D3142] mb-4">404</h1>
      <h2 className="text-2xl md:text-3xl font-bold mb-6 text-balance">
        The room you&apos;re looking for isn&apos;t here.
      </h2>
      <p className="text-lg text-muted-foreground max-w-md mb-12 leading-relaxed">
        It looks like this property has been unlisted or moved to a different neighborhood. Let&apos;s get you back on
        track.
      </p>

      <div className="flex flex-col sm:flex-row gap-4 w-full max-w-xs sm:max-w-none justify-center">
        <Link href="/">
          <Button
            variant="outline"
            className="w-full sm:w-auto px-8 h-14 rounded-2xl border-[#DED9D0] font-bold bg-white text-base gap-2"
          >
            <ArrowLeft className="size-4" /> Back to Home
          </Button>
        </Link>
        <Link href="/explore">
          <Button className="w-full sm:w-auto px-8 h-14 rounded-2xl bg-[#2D3142] hover:bg-[#1F222E] font-bold text-base gap-2">
            <Search className="size-4" /> Browse Rooms
          </Button>
        </Link>
      </div>

      <div className="mt-20 flex items-center gap-8 text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em]">
        <span>GrihaMate</span>
        <div className="size-1 rounded-full bg-[#DED9D0]" />
        <span>Verified Only</span>
        <div className="size-1 rounded-full bg-[#DED9D0]" />
        <span>Since 2023</span>
      </div>
    </div>
  )
}
