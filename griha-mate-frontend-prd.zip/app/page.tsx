import { ArrowRight, Search, ShieldCheck, MapPin, Sparkles, Building2, Users } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AISearchDialog } from "@/components/ai-search-dialog"
import { FeaturedListings } from "@/components/featured-listings"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-[#F2EDE4] text-[#1A1A1A]">
      {/* Navigation */}
      <header className="sticky top-0 z-50 flex h-20 items-center justify-between px-6 md:px-12 backdrop-blur-md bg-[#F2EDE4]/80 border-b border-[#DED9D0]">
        <div className="flex items-center gap-2">
          <div className="size-8 rounded-lg bg-[#2D3142] flex items-center justify-center">
            <Building2 className="text-white size-5" />
          </div>
          <span className="text-xl font-bold tracking-tight">GrihaMate</span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <Link href="#" className="hover:text-primary transition-colors">
            Find Rooms
          </Link>
          <Link href="#" className="hover:text-primary transition-colors">
            List Your Property
          </Link>
          <Link href="#" className="hover:text-primary transition-colors">
            How it Works
          </Link>
          <Link href="#" className="hover:text-primary transition-colors">
            Safety
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Link href="#" className="hidden sm:block text-sm font-medium hover:underline underline-offset-4">
            Log in
          </Link>
          <Button className="rounded-full bg-[#2D3142] hover:bg-[#1F222E] text-white px-6">Get Started</Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative px-6 py-20 md:py-32 flex flex-col items-center text-center max-w-5xl mx-auto">
          <Badge
            variant="outline"
            className="mb-6 py-1 px-4 rounded-full border-[#DED9D0] bg-[#E8E3D8] text-[#2D3142] flex items-center gap-2"
          >
            <div className="size-1.5 rounded-full bg-green-500 animate-pulse" />
            New: AI-powered roommate matching is live
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-[1.1] tracking-tight">
            Verified Rooms & Roommates for Modern Living in Nepal
          </h1>
          <p className="text-lg md:text-xl text-[#4A4A4A] mb-12 max-w-2xl leading-relaxed">
            Discover your next home with 360° virtual tours, verified listings, and a community of trusted renters.
            Secure, transparent, and easy.
          </p>

          <div className="w-full max-w-2xl relative mb-16">
            <div className="bg-white p-2 rounded-2xl shadow-xl border border-[#DED9D0] flex flex-col sm:flex-row gap-2">
              <div className="flex-1 flex items-center px-4 gap-3">
                <Search className="size-5 text-muted-foreground" />
                <Input
                  placeholder="Where do you want to live?"
                  className="border-none bg-transparent focus-visible:ring-0 text-base"
                />
              </div>
              <div className="flex items-center px-4 gap-2 sm:border-l border-[#DED9D0]">
                <MapPin className="size-5 text-muted-foreground" />
                <span className="text-sm font-medium whitespace-nowrap">Kathmandu, NP</span>
              </div>
              <AISearchDialog />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 w-full border-t border-[#DED9D0] pt-12 text-left">
            <div>
              <div className="text-3xl font-bold">15k+</div>
              <div className="text-sm text-muted-foreground">Verified Listings</div>
            </div>
            <div>
              <div className="text-3xl font-bold">98%</div>
              <div className="text-sm text-muted-foreground">Tenant Satisfaction</div>
            </div>
            <div>
              <div className="text-3xl font-bold">360°</div>
              <div className="text-sm text-muted-foreground">Virtual Tours</div>
            </div>
            <div>
              <div className="text-3xl font-bold">24/7</div>
              <div className="text-sm text-muted-foreground">Local Support</div>
            </div>
          </div>
        </section>

        {/* Feature Grid Inspired by OpenAI/Vercel Layout */}
        <section className="px-6 py-24 md:px-12 bg-white rounded-[2rem] mx-4 mb-24 shadow-sm border border-[#DED9D0]">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
              <div className="max-w-xl">
                <Badge className="bg-[#E8E3D8] text-[#2D3142] hover:bg-[#E8E3D8] mb-4">Core Features</Badge>
                <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                  Built for trust, designed for simplicity.
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  We've reimagined the rental experience from the ground up, focusing on security and transparency at
                  every step.
                </p>
              </div>
              <Button
                variant="outline"
                className="rounded-full px-6 border-[#DED9D0] hover:bg-[#F2EDE4] bg-transparent"
              >
                Explore all features <ArrowRight className="ml-2 size-4" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-[#F9F7F2] border-none shadow-none overflow-hidden group">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="size-12 rounded-xl bg-white flex items-center justify-center shadow-sm mb-6 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="text-[#2D3142] size-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Identity Verification</h3>
                  <p className="text-muted-foreground mb-8">
                    Every landlord and roommate undergoes a strict background check to ensure your safety.
                  </p>
                  <div className="mt-auto pt-4 border-t border-[#E8E3D8]">
                    <span className="text-sm font-semibold flex items-center gap-2">
                      Learn more <ArrowRight className="size-3" />
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#F9F7F2] border-none shadow-none overflow-hidden group">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="size-12 rounded-xl bg-white flex items-center justify-center shadow-sm mb-6 group-hover:scale-110 transition-transform">
                    <Sparkles className="text-[#2D3142] size-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">AI-Powered Matching</h3>
                  <p className="text-muted-foreground mb-8">
                    Find roommates who share your lifestyle, habits, and values with our smart matchmaking engine.
                  </p>
                  <div className="mt-auto pt-4 border-t border-[#E8E3D8]">
                    <span className="text-sm font-semibold flex items-center gap-2">
                      See how it works <ArrowRight className="size-3" />
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#F9F7F2] border-none shadow-none overflow-hidden group">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="size-12 rounded-xl bg-white flex items-center justify-center shadow-sm mb-6 group-hover:scale-110 transition-transform">
                    <Users className="text-[#2D3142] size-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Community First</h3>
                  <p className="text-muted-foreground mb-8">
                    Join thousands of verified renters in Nepal. Read reviews and share your own rental stories.
                  </p>
                  <div className="mt-auto pt-4 border-t border-[#E8E3D8]">
                    <span className="text-sm font-semibold flex items-center gap-2">
                      Join community <ArrowRight className="size-3" />
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Featured Listings Section */}
        <FeaturedListings />

        {/* 360 Tour Showcase */}
        <section className="px-6 py-24 md:px-12 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative aspect-video rounded-3xl overflow-hidden bg-white shadow-2xl border border-[#DED9D0]">
              <img
                src="/360-virtual-tour-of-modern-apartment-living-room.jpg"
                alt="360 Tour Preview"
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
                <div className="size-16 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 transition-transform">
                  <Sparkles className="size-8 text-[#2D3142]" />
                </div>
              </div>
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-white/95 backdrop-blur-md rounded-2xl flex items-center justify-between shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-full bg-[#E8E3D8] flex items-center justify-center">
                    <MapPin className="size-5 text-[#2D3142]" />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Shanti Nagar, Kathmandu</div>
                    <div className="text-xs text-muted-foreground">Modern 2BHK Apartment</div>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-[#2D3142] text-white">
                  Live 360°
                </Badge>
              </div>
            </div>
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Inspect your next home from anywhere.
              </h2>
              <p className="text-lg text-[#4A4A4A] mb-8 leading-relaxed">
                Save time and energy with our immersive virtual tours. Walk through every corner of the property, check
                the lighting, and see the layout before you even step foot in the neighborhood.
              </p>
              <ul className="space-y-4 mb-10">
                {[
                  "High-definition 360° panoramas",
                  "Accurate floor plan measurements",
                  "Verified neighborhood walkability scores",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 font-medium">
                    <div className="size-5 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                      <ShieldCheck className="size-3" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
              <Button className="bg-[#2D3142] hover:bg-[#1F222E] rounded-full px-8 h-12">View Sample Tours</Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="px-6 py-20 md:px-12 border-t border-[#DED9D0] bg-white">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="size-8 rounded-lg bg-[#2D3142] flex items-center justify-center">
                <Building2 className="text-white size-5" />
              </div>
              <span className="text-xl font-bold tracking-tight">GrihaMate</span>
            </div>
            <p className="text-muted-foreground max-w-xs mb-8">
              Empowering the modern renter in Nepal with trust, technology, and community.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-6">Product</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Find Rooms
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  List Property
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  360° Tours
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Pricing
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6">Company</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Press
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6">Support</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Help Center
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Safety Center
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-[#DED9D0] flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>© 2026 GrihaMate. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link href="#" className="hover:text-primary">
              Twitter
            </Link>
            <Link href="#" className="hover:text-primary">
              Instagram
            </Link>
            <Link href="#" className="hover:text-primary">
              LinkedIn
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
