import type * as React from "react"
import { Building2, LayoutDashboard, Search, Heart, MessageSquare, Settings, LogOut, Plus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#F2EDE4] flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-[#DED9D0] bg-white hidden lg:flex flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-[#F2EDE4]">
          <Link href="/" className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-[#2D3142] flex items-center justify-center">
              <Building2 className="text-white size-5" />
            </div>
            <span className="text-xl font-bold tracking-tight">GrihaMate</span>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-2 mt-4">
          <NavItem href="/dashboard" icon={LayoutDashboard} label="Overview" active />
          <NavItem href="/explore" icon={Search} label="Find Rooms" />
          <NavItem href="#" icon={Heart} label="Favorites" />
          <NavItem href="#" icon={MessageSquare} label="Messages" badge="3" />
          <NavItem href="#" icon={Settings} label="Settings" />
        </nav>

        <div className="p-4 border-t border-[#F2EDE4]">
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl"
          >
            <LogOut className="size-5" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-[#DED9D0] bg-white/50 backdrop-blur-sm flex items-center justify-between px-8">
          <h2 className="font-bold text-lg">Dashboard</h2>
          <div className="flex items-center gap-4">
            <Button size="sm" className="bg-[#2D3142] hover:bg-[#1F222E] rounded-full gap-2 px-4">
              <Plus className="size-4" /> New Listing
            </Button>
            <div className="size-8 rounded-full bg-[#E8E3D8] border border-[#DED9D0] flex items-center justify-center font-bold text-xs">
              BK
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-8">{children}</main>
      </div>
    </div>
  )
}

function NavItem({ href, icon: Icon, label, active, badge }: any) {
  return (
    <Link
      href={href}
      className={`flex items-center justify-between px-4 py-3 rounded-xl transition-colors ${
        active ? "bg-[#2D3142] text-white" : "text-muted-foreground hover:bg-[#F9F7F2] hover:text-[#2D3142]"
      }`}
    >
      <div className="flex items-center gap-3">
        <Icon className="size-5" />
        <span className="font-medium text-sm">{label}</span>
      </div>
      {badge && (
        <span
          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${active ? "bg-white text-[#2D3142]" : "bg-red-500 text-white"}`}
        >
          {badge}
        </span>
      )}
    </Link>
  )
}
