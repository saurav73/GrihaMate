import { ArrowUpRight, Home, Users, CheckCircle2, Clock, MapPin, Star } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function DashboardPage() {
  const isLandlord = true // Mock role toggle for demo

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold mb-2">Welcome back, Bishal</h1>
        <p className="text-muted-foreground">Here&apos;s what&apos;s happening with your properties today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard title="Active Listings" value="3" icon={Home} trend="+1 this month" />
        <StatsCard title="Total Views" value="1,240" icon={Users} trend="+12% from last week" />
        <StatsCard title="Applications" value="8" icon={Clock} trend="3 pending" />
        <StatsCard title="Total Earnings" value="Rs. 85k" icon={CheckCircle2} trend="Paid this month" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Section */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-[#DED9D0] rounded-3xl overflow-hidden bg-white shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xl font-bold">Your Listings</CardTitle>
              <Button variant="link" className="text-[#2D3142] p-0 font-bold">
                View all
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { title: "Modern 2BHK Apartment", area: "Shanti Nagar", price: "35k", status: "Active", views: 420 },
                  { title: "Cozy Rooftop Room", area: "Lazimpat", price: "22k", status: "Active", views: 180 },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 p-4 bg-[#F9F7F2] rounded-2xl border border-[#DED9D0] group hover:border-[#2D3142] transition-colors"
                  >
                    <div className="size-16 rounded-xl bg-white border border-[#DED9D0] overflow-hidden">
                      <img
                        src={`/interior-.jpg?height=100&width=100&query=interior-${i}`}
                        alt="Room"
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-bold">{item.title}</h4>
                        <Badge className="bg-green-100 text-green-700 border-none text-[10px]">{item.status}</Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="size-3" /> {item.area}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="size-3" /> {item.views} views
                        </span>
                        <span className="font-bold text-[#2D3142]">Rs. {item.price}/mo</span>
                      </div>
                    </div>
                    <Button size="icon" variant="ghost" className="rounded-full">
                      <ArrowUpRight className="size-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Section */}
        <div className="space-y-6">
          <Card className="border-[#DED9D0] rounded-3xl overflow-hidden bg-white shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-bold">Recent Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "Rahul S.", room: "2BHK Shanti Nagar", time: "2h ago", avatar: "RS" },
                  { name: "Priya K.", room: "Rooftop Lazimpat", time: "5h ago", avatar: "PK" },
                ].map((app, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="size-10 rounded-full bg-[#E8E3D8] flex items-center justify-center font-bold text-xs text-[#2D3142]">
                      {app.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold truncate">{app.name}</div>
                      <div className="text-[10px] text-muted-foreground truncate">Applied for {app.room}</div>
                    </div>
                    <div className="text-[10px] text-muted-foreground whitespace-nowrap">{app.time}</div>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6 bg-[#2D3142] hover:bg-[#1F222E] rounded-xl h-10">Review All</Button>
            </CardContent>
          </Card>

          <Card className="bg-[#2D3142] text-white border-none rounded-3xl p-6 relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <Star className="size-5 fill-yellow-400 text-yellow-400" />
                <span className="font-bold">Trust Score: 98</span>
              </div>
              <p className="text-sm text-white/80 mb-6">
                Your profile is highly rated. Verified landlords get 3x more views.
              </p>
              <Button className="bg-white text-[#2D3142] hover:bg-white/90 rounded-full w-full font-bold">
                Improve Profile
              </Button>
            </div>
            <div className="absolute -right-4 -bottom-4 size-32 bg-white/10 rounded-full blur-2xl" />
          </Card>
        </div>
      </div>
    </div>
  )
}

function StatsCard({ title, value, icon: Icon, trend }: any) {
  return (
    <Card className="border-[#DED9D0] rounded-3xl bg-white shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="size-10 rounded-xl bg-[#F9F7F2] border border-[#DED9D0] flex items-center justify-center">
            <Icon className="size-5 text-[#2D3142]" />
          </div>
          <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{trend}</span>
        </div>
        <div>
          <div className="text-2xl font-bold mb-1">{value}</div>
          <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{title}</div>
        </div>
      </CardContent>
    </Card>
  )
}
