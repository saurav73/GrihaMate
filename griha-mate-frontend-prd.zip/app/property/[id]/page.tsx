import {
  MapPin,
  ShieldCheck,
  Wifi,
  Utensils,
  Zap,
  Users,
  ArrowLeft,
  Heart,
  Share2,
  Star,
  Calendar,
  MessageCircle,
  Navigation,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Property360Viewer } from "@/components/property-360-viewer"
import Link from "next/link"

export default function PropertyDetailsPage({ params }: { params: { id: string } }) {
  const propertyId = params.id

  return (
    <div className="min-h-screen bg-[#F2EDE4] pb-20">
      <header className="px-6 py-6 border-b border-[#DED9D0] bg-white/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/explore">
            <Button variant="ghost" className="gap-2 -ml-2">
              <ArrowLeft className="size-4" /> Back to Explore
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="rounded-full border-[#DED9D0] bg-white">
              <Heart className="size-4" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full border-[#DED9D0] bg-white">
              <Share2 className="size-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <Property360Viewer
              imageUrl="/360-virtual-tour-of-modern-apartment-living-room.jpg"
              title="Modern 2BHK Apartment"
            />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 flex items-center gap-1 border-none">
                    <ShieldCheck className="size-3" /> Verified Listing
                  </Badge>
                  <Badge variant="outline" className="border-[#DED9D0] text-muted-foreground">
                    360° Virtual Tour
                  </Badge>
                </div>
                <div className="flex items-center gap-1 text-sm font-bold">
                  <Star className="size-4 fill-yellow-400 text-yellow-400" />
                  <span>4.8</span>
                  <span className="text-muted-foreground font-normal">(24 reviews)</span>
                </div>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Modern 2BHK Apartment with Balcony</h1>
              <div className="flex items-center gap-4 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <MapPin className="size-4" />
                  <span>Shanti Nagar, Kathmandu (Near Civil Bank)</span>
                </div>
                <div className="flex items-center gap-2 text-[#2D3142] font-semibold text-sm bg-white/50 px-3 py-1 rounded-full border border-[#DED9D0]">
                  <Navigation className="size-3" /> 0.5 km from your current location
                </div>
              </div>
            </div>

            <Tabs defaultValue="description" className="w-full">
              <TabsList className="bg-transparent border-b border-[#DED9D0] rounded-none w-full justify-start gap-8 h-auto p-0 mb-6">
                <TabsTrigger
                  value="description"
                  className="bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-[#2D3142] data-[state=active]:bg-transparent px-0 py-2 h-auto text-base font-semibold"
                >
                  Description
                </TabsTrigger>
                <TabsTrigger
                  value="amenities"
                  className="bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-[#2D3142] data-[state=active]:bg-transparent px-0 py-2 h-auto text-base font-semibold"
                >
                  Amenities
                </TabsTrigger>
                <TabsTrigger
                  value="location"
                  className="bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-[#2D3142] data-[state=active]:bg-transparent px-0 py-2 h-auto text-base font-semibold"
                >
                  Location
                </TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  Beautifully designed 2BHK apartment located in the heart of Shanti Nagar. This property features a
                  spacious living area with large windows, a modern kitchen with marble countertops, and a cozy balcony
                  offering a great view of the city.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4">
                  <div className="bg-white p-4 rounded-2xl border border-[#DED9D0]">
                    <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-bold">
                      Bedrooms
                    </div>
                    <div className="font-bold">2 Rooms</div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-[#DED9D0]">
                    <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-bold">
                      Bathrooms
                    </div>
                    <div className="font-bold">1 Shared</div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-[#DED9D0]">
                    <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-bold">Size</div>
                    <div className="font-bold">850 sqft</div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-[#DED9D0]">
                    <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-bold">Floor</div>
                    <div className="font-bold">3rd Floor</div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="amenities">
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: Wifi, label: "High Speed WiFi" },
                    { icon: Utensils, label: "Modular Kitchen" },
                    { icon: Zap, label: "24/7 Power Backup" },
                    { icon: Users, label: "CCTV Security" },
                  ].map((a, i) => (
                    <div key={i} className="flex items-center gap-3 p-4 bg-white rounded-xl border border-[#DED9D0]">
                      <a.icon className="size-5 text-[#2D3142]" />
                      <span className="font-medium">{a.label}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="location" className="space-y-4">
                <div className="aspect-video w-full rounded-3xl overflow-hidden border border-[#DED9D0] relative bg-[#E8E3D8]">
                  <div className="absolute inset-0 flex items-center justify-center flex-col text-muted-foreground">
                    <MapPin className="size-12 mb-2 opacity-20" />
                    <p className="font-medium text-lg">Interactive Map View</p>
                    <p className="text-sm">Explore nearby schools, hospitals, and transit</p>
                  </div>
                  <img
                    src={`/placeholder.svg?height=600&width=1200&query=map+showing+Shanti+Nagar+Kathmandu`}
                    alt="Property Map"
                    className="w-full h-full object-cover opacity-50"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-white rounded-2xl border border-[#DED9D0]">
                    <h4 className="font-bold mb-2 flex items-center gap-2">
                      <Navigation className="size-4" /> Transit
                    </h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>Baneshwor Bus Stop - 10 min walk</li>
                      <li>Airport - 15 min drive</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-white rounded-2xl border border-[#DED9D0]">
                    <h4 className="font-bold mb-2 flex items-center gap-2">
                      <ShieldCheck className="size-4" /> Neighborhood
                    </h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>Very safe, residential area</li>
                      <li>Verified by GrihaMate team</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar Sidebar - Pricing & Contact */}
          <div className="space-y-6">
            <Card className="border-[#DED9D0] shadow-xl bg-white rounded-3xl sticky top-28">
              <CardContent className="p-8">
                <div className="flex items-end gap-1 mb-8">
                  <div className="text-4xl font-bold">Rs. 35,000</div>
                  <div className="text-muted-foreground pb-1">/ month</div>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex justify-between items-center py-3 border-b border-[#F2EDE4]">
                    <span className="text-muted-foreground">Security Deposit</span>
                    <span className="font-bold">Rs. 35,000</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-[#F2EDE4]">
                    <span className="text-muted-foreground">Lease Term</span>
                    <span className="font-bold">Min. 6 Months</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-[#F2EDE4]">
                    <span className="text-muted-foreground">Available from</span>
                    <span className="font-bold">Oct 15, 2025</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button className="w-full bg-[#2D3142] hover:bg-[#1F222E] h-14 rounded-2xl text-lg font-bold flex items-center justify-center gap-2">
                    <Calendar className="size-5" /> Schedule a Visit
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full h-14 rounded-2xl border-[#DED9D0] font-bold bg-transparent flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="size-5" /> Message Landlord
                  </Button>
                </div>

                <div className="mt-8 flex items-center gap-3 p-4 bg-[#F9F7F2] rounded-2xl border border-[#DED9D0]">
                  <div className="size-10 rounded-full bg-[#2D3142] flex items-center justify-center text-white font-bold">
                    BK
                  </div>
                  <div>
                    <div className="text-sm font-bold">Bishal K.</div>
                    <div className="text-xs text-muted-foreground">Landlord since 2023</div>
                  </div>
                  <Badge className="ml-auto bg-green-100 text-green-700 border-none">Fast Reply</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
