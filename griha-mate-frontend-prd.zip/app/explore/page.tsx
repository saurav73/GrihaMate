import { Search, MapPin, SlidersHorizontal, Grid, MapIcon, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const rooms = [
  {
    id: 1,
    title: "Modern 2BHK",
    area: "Shanti Nagar",
    price: 35000,
    type: "Apartment",
    img: "/modern-living-room.png",
    distance: 0.5, // adding distance for proximity search simulation
  },
  { id: 2, title: "Cozy Studio", area: "Patan", price: 15000, type: "Studio", img: "/cozy-bedroom.png", distance: 1.2 },
  {
    id: 3,
    title: "Rooftop Room",
    area: "Lazimpat",
    price: 22000,
    type: "Room",
    img: "/rooftop-view.jpg",
    distance: 2.5,
  },
  {
    id: 4,
    title: "Family Flat",
    area: "Baneshwor",
    price: 45000,
    type: "Flat",
    img: "/modern-flat-living-room.jpg",
    distance: 0.8,
  },
  {
    id: 5,
    title: "Minimalist Space",
    area: "Balkhu",
    price: 12000,
    type: "Room",
    img: "/minimalist-bedroom.png",
    distance: 3.1,
  },
  {
    id: 6,
    title: "Luxury Penthouse",
    area: "Jhamsikhel",
    price: 85000,
    type: "Penthouse",
    img: "/luxury-penthouse.png",
    distance: 1.5,
  },
]

export default function ExplorePage() {
  const sortedRooms = [...rooms].sort((a, b) => (a.distance || 0) - (b.distance || 0))

  return (
    <div className="min-h-screen bg-[#F2EDE4] flex flex-col">
      <header className="sticky top-0 z-50 bg-[#F2EDE4]/80 backdrop-blur-md border-b border-[#DED9D0] px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-4 w-full md:w-auto">
            <Link href="/" className="font-bold text-xl">
              GrihaMate
            </Link>
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search areas or properties..."
                className="pl-10 bg-white border-[#DED9D0] rounded-xl"
              />
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {["Apartment", "House", "Room", "Studio", "Flat"].map((f) => (
              <Button
                key={f}
                variant="outline"
                size="sm"
                className="rounded-full border-[#DED9D0] bg-white whitespace-nowrap"
              >
                {f}
              </Button>
            ))}
            <div className="w-px h-6 bg-[#DED9D0] mx-2" />
            <Button
              variant="outline"
              size="sm"
              className="rounded-full border-[#DED9D0] bg-white flex items-center gap-2"
            >
              <SlidersHorizontal className="size-4" /> Filters
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold">Properties in Nepal</h1>
            <p className="text-muted-foreground text-sm">Showing the closest verified results to you</p>
          </div>
          <div className="flex bg-white rounded-xl p-1 border border-[#DED9D0]">
            <Button size="sm" variant="ghost" className="rounded-lg bg-[#F2EDE4]">
              <Grid className="size-4 mr-2" /> Grid
            </Button>
            <Button size="sm" variant="ghost" className="rounded-lg">
              <MapIcon className="size-4 mr-2" /> Map
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {sortedRooms.map((room) => (
            <Link key={room.id} href={`/property/${room.id}`}>
              <Card className="group border-[#DED9D0] overflow-hidden hover:shadow-lg transition-all relative">
                {room.id === sortedRooms[0].id && (
                  <div className="absolute top-3 right-3 z-10">
                    <Badge className="bg-[#2D3142] text-white border-none flex items-center gap-1">
                      <Navigation className="size-3" /> Closest
                    </Badge>
                  </div>
                )}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={room.img || "/placeholder.svg"}
                    alt={room.title}
                    className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
                  />
                  <Badge className="absolute top-3 left-3 bg-white/90 text-[#2D3142] border-none text-[10px] uppercase font-bold tracking-wider">
                    360° Tour
                  </Badge>
                </div>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold">{room.title}</h3>
                    <Badge variant="secondary" className="bg-[#E8E3D8] text-[#2D3142] text-[10px]">
                      {room.type}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                    <div className="flex items-center gap-1">
                      <MapPin className="size-3" /> {room.area}
                    </div>
                    <span className="font-medium text-[#2D3142]">{room.distance} km away</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-[#DED9D0] pt-3 mt-auto">
                    <div className="font-bold">Rs. {room.price.toLocaleString()}</div>
                    <div className="text-[10px] text-muted-foreground font-medium">/ month</div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
