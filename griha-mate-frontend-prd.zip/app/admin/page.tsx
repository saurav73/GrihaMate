import {
  Users,
  Building2,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Search,
  Filter,
  Mail,
  Ban,
  MoreHorizontal,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Suspense } from "react" // added Suspense to handle potential useSearchParams usage in sub-components

export default function AdminDashboard() {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Platform Overview</h1>
          <p className="text-muted-foreground">Manage users, listings, and system health for GrihaMate.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="border-[#DED9D0] bg-white font-bold h-10 rounded-xl px-6">
            Generate Report
          </Button>
          <Button className="bg-[#2D3142] hover:bg-[#1F222E] font-bold h-10 rounded-xl px-6">System Status</Button>
        </div>
      </div>

      {/* Admin KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPIButton title="Total Users" value="24,512" icon={Users} change="+12.5%" positive />
        <KPIButton title="Live Listings" value="1,240" icon={Building2} change="+3.2%" positive />
        <KPIButton title="Verification Requests" value="12" icon={CheckCircle2} change="Action Required" warning />
        <KPIButton title="Reported Items" value="3" icon={AlertCircle} change="-15%" negative />
      </div>

      <Suspense fallback={null}>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-white border border-[#DED9D0] p-1 rounded-2xl mb-6">
            <TabsTrigger
              value="overview"
              className="rounded-xl px-6 font-bold data-[state=active]:bg-[#2D3142] data-[state=active]:text-white"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="landlords"
              className="rounded-xl px-6 font-bold data-[state=active]:bg-[#2D3142] data-[state=active]:text-white"
            >
              Landlords
            </TabsTrigger>
            <TabsTrigger
              value="renters"
              className="rounded-xl px-6 font-bold data-[state=active]:bg-[#2D3142] data-[state=active]:text-white"
            >
              Renters
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              {/* Pending Verifications */}
              <Card className="xl:col-span-2 border-[#DED9D0] rounded-3xl bg-white shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-xl font-bold">Pending Landlord Verifications</CardTitle>
                    <CardDescription>Verify identities to maintain platform trust.</CardDescription>
                  </div>
                  <Button variant="ghost" className="text-muted-foreground">
                    View all
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-0 divide-y divide-[#F2EDE4]">
                    {[
                      { name: "Suman Thapa", date: "2 mins ago", doc: "Citizenship ID", status: "High Priority" },
                      { name: "Anish Gurung", date: "15 mins ago", doc: "Passport", status: "Medium" },
                      { name: "Priya Rai", date: "1 hour ago", doc: "Citizenship ID", status: "Medium" },
                      { name: "Bibek Shah", date: "3 hours ago", doc: "Rental License", status: "Low" },
                    ].map((user, i) => (
                      <div key={i} className="py-4 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <div className="size-10 rounded-full bg-[#F9F7F2] border border-[#DED9D0] flex items-center justify-center font-bold text-xs">
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-sm group-hover:text-[#2D3142] transition-colors">
                              {user.name}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">
                              {user.doc} • {user.date}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge
                            variant="outline"
                            className={`text-[10px] font-bold border-none px-2 ${user.status === "High Priority" ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"}`}
                          >
                            {user.status}
                          </Badge>
                          <Button
                            variant="outline"
                            size="sm"
                            className="rounded-lg h-8 px-4 font-bold border-[#DED9D0] bg-transparent"
                          >
                            Review
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* System Activity */}
              <Card className="border-[#DED9D0] rounded-3xl bg-white shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl font-bold">Recent System Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {[
                      { event: "New Landlord Signed Up", time: "10:24 AM", icon: Users, color: "bg-blue-500" },
                      { event: "Listing #429 Verified", time: "09:45 AM", icon: CheckCircle2, color: "bg-green-500" },
                      { event: "Auto-moderation Flag", time: "09:12 AM", icon: AlertCircle, color: "bg-orange-500" },
                      { event: "Database Backup Success", time: "03:00 AM", icon: ShieldCheck, color: "bg-[#2D3142]" },
                    ].map((log, i) => (
                      <div key={i} className="flex gap-4">
                        <div className="relative">
                          <div
                            className={`size-8 rounded-lg ${log.color} flex items-center justify-center text-white shadow-md`}
                          >
                            <log.icon className="size-4" />
                          </div>
                          {i !== 3 && <div className="absolute top-8 left-4 w-px h-8 bg-[#DED9D0] -translate-x-1/2" />}
                        </div>
                        <div>
                          <div className="text-sm font-bold">{log.event}</div>
                          <div className="text-[10px] text-muted-foreground font-medium">{log.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    className="w-full mt-8 border-[#DED9D0] rounded-xl h-10 font-bold bg-transparent"
                  >
                    View Audit Logs
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="landlords">
            <ManagementTable
              title="Landlord Management"
              description="Manage property owners, their verification status, and active listings."
              type="landlord"
            />
          </TabsContent>

          <TabsContent value="renters">
            <ManagementTable
              title="Renter Management"
              description="Manage student and professional seekers, review their verification and history."
              type="renter"
            />
          </TabsContent>
        </Tabs>
      </Suspense>
    </div>
  )
}

function KPIButton({ title, value, icon: Icon, change, positive, negative, warning }: any) {
  return (
    <Card className="border-[#DED9D0] rounded-3xl bg-white hover:shadow-md transition-shadow cursor-default">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="size-10 rounded-xl bg-[#F9F7F2] border border-[#DED9D0] flex items-center justify-center">
            <Icon className="size-5 text-[#2D3142]" />
          </div>
          <div className="flex items-center gap-1">
            {positive && <ArrowUpRight className="size-3 text-green-600" />}
            {negative && <ArrowDownRight className="size-3 text-red-600" />}
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                positive
                  ? "bg-green-50 text-green-700"
                  : negative
                    ? "bg-red-50 text-red-700"
                    : "bg-orange-50 text-orange-700"
              }`}
            >
              {change}
            </span>
          </div>
        </div>
        <div className="text-2xl font-bold mb-0.5">{value}</div>
        <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{title}</div>
      </CardContent>
    </Card>
  )
}

function ManagementTable({
  title,
  description,
  type,
}: { title: string; description: string; type: "landlord" | "renter" }) {
  const users =
    type === "landlord"
      ? [
          { name: "Suman Thapa", email: "suman@example.com", listings: 3, status: "Verified", joined: "Oct 2025" },
          { name: "Anish Gurung", email: "anish@example.com", listings: 1, status: "Pending", joined: "Nov 2025" },
          { name: "Maya Shrestha", email: "maya@example.com", listings: 5, status: "Verified", joined: "Aug 2025" },
        ]
      : [
          { name: "Rahul Sharma", email: "rahul@example.com", saved: 12, status: "Verified", joined: "Dec 2025" },
          { name: "Sita Rai", email: "sita@example.com", saved: 4, status: "Active", joined: "Nov 2025" },
          { name: "Kiran Kc", email: "kiran@example.com", saved: 0, status: "Suspended", joined: "July 2025" },
        ]

  return (
    <Card className="border-[#DED9D0] rounded-3xl bg-white shadow-sm overflow-hidden">
      <CardHeader className="border-b border-[#F2EDE4] bg-[#F9F7F2]/50">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-xl font-bold">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input placeholder="Search users..." className="pl-10 rounded-xl border-[#DED9D0] bg-white h-10" />
            </div>
            <Button variant="outline" size="icon" className="rounded-xl border-[#DED9D0] bg-white h-10 w-10 shrink-0">
              <Filter className="size-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F9F7F2]/30 border-b border-[#F2EDE4]">
                <th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                  User
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                  {type === "landlord" ? "Listings" : "Saved Rooms"}
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                  Status
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                  Joined
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase tracking-widest text-right">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2EDE4]">
              {users.map((user, i) => (
                <tr key={i} className="hover:bg-[#F9F7F2]/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="size-9 rounded-full bg-[#2D3142] text-white flex items-center justify-center font-bold text-xs">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-sm">{user.name}</div>
                        <div className="text-[10px] text-muted-foreground font-medium">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge
                      variant="secondary"
                      className="bg-[#F2EDE4] text-[#2D3142] hover:bg-[#DED9D0] rounded-lg px-2"
                    >
                      {type === "landlord" ? (user as any).listings : (user as any).saved}
                    </Badge>
                  </td>
                  <td className="px-6 py-4">
                    <Badge
                      className={`rounded-lg px-2 font-bold text-[10px] border-none ${
                        user.status === "Verified"
                          ? "bg-green-50 text-green-700"
                          : user.status === "Pending"
                            ? "bg-orange-50 text-orange-700"
                            : user.status === "Suspended"
                              ? "bg-red-50 text-red-700"
                              : "bg-blue-50 text-blue-700"
                      }`}
                    >
                      {user.status}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-xs font-medium text-muted-foreground">{user.joined}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="icon" className="size-8 rounded-lg hover:bg-white hover:shadow-sm">
                        <Mail className="size-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="size-8 rounded-lg hover:bg-white hover:shadow-sm">
                        <Ban className="size-4 text-red-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="size-8 rounded-lg hover:bg-white hover:shadow-sm">
                        <MoreHorizontal className="size-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-6 border-t border-[#F2EDE4] bg-[#F9F7F2]/20 flex items-center justify-between">
          <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
            Showing 1-3 of 2,410 {type}s
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl border-[#DED9D0] bg-white h-8 px-4 font-bold text-xs"
              disabled
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl border-[#DED9D0] bg-white h-8 px-4 font-bold text-xs"
            >
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
