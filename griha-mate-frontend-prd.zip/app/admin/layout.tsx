import type * as React from "react"
import { Building2, ShieldCheck, Users, FileText, BarChart3, Settings, LogOut, Bell } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#F2EDE4] flex">
      {/* Admin Sidebar */}
      <aside className="w-64 border-r border-[#DED9D0] bg-white hidden lg:flex flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-[#F2EDE4]">
          <Link href="/admin" className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-[#2D3142] flex items-center justify-center">
              <ShieldCheck className="text-white size-5" />
            </div>
            <div>
              <span className="text-lg font-bold block leading-tight">GrihaMate</span>
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Admin Panel</span>
            </div>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-1 mt-4">
          <AdminNavItem href="/admin" icon={BarChart3} label="System Overview" active />
          <AdminNavItem href="#" icon={Users} label="User Verification" badge="12" />
          <AdminNavItem href="#" icon={FileText} label="Listing Moderation" badge="5" />
          <AdminNavItem href="#" icon={Building2} label="Property Analytics" />
          <AdminNavItem href="#" icon={Settings} label="System Config" />
        </nav>

        <div className="p-4 border-t border-[#F2EDE4]">
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-muted-foreground hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
          >
            <LogOut className="size-5" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Admin Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-[#DED9D0] bg-white flex items-center justify-between px-8">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-100 font-bold px-2 py-0.5">
              Production
            </Badge>
          </div>
          <div className="flex items-center gap-4">
            <Button size="icon" variant="ghost" className="relative text-muted-foreground">
              <Bell className="size-5" />
              <span className="absolute top-2 right-2 size-2 bg-red-500 rounded-full border-2 border-white" />
            </Button>
            <div className="h-8 w-px bg-[#DED9D0]" />
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-bold">Admin User</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest">Super Admin</div>
              </div>
              <div className="size-9 rounded-full bg-[#2D3142] text-white flex items-center justify-center font-bold text-xs shadow-md">
                AD
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-8">{children}</main>
      </div>
    </div>
  )
}

function AdminNavItem({ href, icon: Icon, label, active, badge }: any) {
  return (
    <Link
      href={href}
      className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 ${
        active ? "bg-[#2D3142] text-white shadow-lg" : "text-muted-foreground hover:bg-[#F9F7F2] hover:text-[#2D3142]"
      }`}
    >
      <div className="flex items-center gap-3">
        <Icon className="size-5" />
        <span className="font-semibold text-sm">{label}</span>
      </div>
      {badge && (
        <span
          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${active ? "bg-white text-[#2D3142]" : "bg-red-500 text-white shadow-sm"}`}
        >
          {badge}
        </span>
      )}
    </Link>
  )
}

import { Badge } from "@/components/ui/badge"
